import React from 'react';

const Listings = () => {
  return (
    <div>
      <h1>Listings Page</h1>
    </div>
  );
};

export default Listings;
