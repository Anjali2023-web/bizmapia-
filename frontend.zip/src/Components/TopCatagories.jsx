import React, { useState } from 'react';
import { motion } from 'framer-motion';
import styled from 'styled-components';
import { useNavigate } from 'react-router-dom';

// Sample icons with added categories
const allCategories = [
  { name: 'Restaurants', icon: '🍽️', color: 'bg-orange-200' },
  { name: 'Hotels', icon: '🏨', color: 'bg-blue-200' },
  { name: 'Beauty Spa', icon: '💆', color: 'bg-pink-200' },
  { name: 'Home Decor', icon: '🛋️', color: 'bg-teal-200' },
  { name: 'Wedding Planning', icon: '👰', color: 'bg-yellow-200' },
  { name: 'Education', icon: '🎓', color: 'bg-purple-200' },
  { name: 'Rent & Hire', icon: '🔧', color: 'bg-red-200' },
  { name: 'Hospitals', icon: '🏥', color: 'bg-blue-200' },
  { name: 'Contractors', icon: '👷', color: 'bg-yellow-200' },
  { name: 'Pet Shops', icon: '🐕', color: 'bg-teal-200' },
  { name: 'PG/Hostels', icon: '🏠', color: 'bg-green-200' },
  { name: 'Estate Agent', icon: '🏘️', color: 'bg-orange-200' },
  { name: 'Dentists', icon: '🦷', color: 'bg-purple-200' },
  { name: 'Gym', icon: '🏋️', color: 'bg-red-200' },
  { name: 'Consultants', icon: '💼', color: 'bg-blue-200' },
  { name: 'Event Organisers', icon: '🎉', color: 'bg-yellow-200' },
  { name: 'Driving Schools', icon: '🚗', color: 'bg-teal-200' },
  { name: 'Packers & Movers', icon: '🚛', color: 'bg-green-200' },
  { name: 'Courier Service', icon: '📦', color: 'bg-gray-200' }
];

const CategoriesContainer = styled.div`
  display: flex;
  flex-wrap: nowrap;
  overflow-x: auto;
  gap: 10px;
  padding: 10px;
  background-color: #f9f9f9;
  width: 100%;

  @media (max-width: 768px) {
    gap: 8px;
  }

  @media (max-width: 480px) {
    gap: 6px;
  }
`;

const CategoryItem = styled(motion.div)`
  text-align: center;
  padding: 8px;
  background-color: #fff;
  border-radius: 10px;
  box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
  cursor: pointer;
  min-width: 80px;
  flex: 0 0 auto;

  &:hover {
    transform: translateY(-5px);
  }
`;

const IconContainer = styled.div`
  font-size: 30px;
  margin-bottom: 5px;

  @media (max-width: 768px) {
    font-size: 24px;
  }

  @media (max-width: 480px) {
    font-size: 20px;
  }
`;

const CategoryName = styled.div`
  font-size: 12px;
  font-weight: bold;

  @media (max-width: 768px) {
    font-size: 10px;
  }

  @media (max-width: 480px) {
    font-size: 8px;
  }
`;

const ButtonContainer = styled.div`
  text-align: center;
  margin-top: 20px;
`;

const MoreButton = styled(motion.button)`
  padding: 8px 16px;
  font-size: 14px;
  font-weight: bold;
  color: #fff;
  background-color: #007bff;
  border: none;
  border-radius: 30px;
  box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
  cursor: pointer;
  transition: background-color 0.3s;

  &:hover {
    background-color: #0056b3;
  }
`;

const Categories = () => {
  const [showAll, setShowAll] = useState(false);
  const navigate = useNavigate();

  const handleMoreClick = () => {
    setShowAll(true);
  };

  const handleButtonClick = () => {
    navigate('/cat'); // Navigate to the page displaying all categories
  };

  const categoriesToShow = showAll ? allCategories : allCategories.slice(0, 13);

  return (
    <div className="container mx-auto px-4 py-8 sm:py-16 bg-gray-50">
      <motion.h2 
        className="text-3xl sm:text-4xl font-bold text-center mb-8 sm:mb-12 text-gray-900"
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
      >
        Explore Popular Categories
      </motion.h2>
      <CategoriesContainer>
        {categoriesToShow.map((category, index) => (
          <CategoryItem
            key={index}
            initial={{ opacity: 0, y: 50 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: index * 0.1 }}
            whileHover={{ scale: 1.05, boxShadow: "0 4px 8px rgba(0,0,0,0.2)" }}
            whileTap={{ scale: 0.95 }}
          >
            <IconContainer>{category.icon}</IconContainer>
            <CategoryName>{category.name}</CategoryName>
          </CategoryItem>
        ))}
      </CategoriesContainer>
      {!showAll && (
        <ButtonContainer>
          <MoreButton
            onClick={handleMoreClick}
            whileHover={{ scale: 1.1 }}
            whileTap={{ scale: 0.9 }}
          >
            More
          </MoreButton>
        </ButtonContainer>
      )}
    </div>
  );
};

export default Categories;
