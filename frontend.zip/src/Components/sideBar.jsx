import React, { useState } from "react";
import { HiOutlineChevronDown } from "react-icons/hi2";
import { useNavigate } from "react-router-dom"; // Import useNavigate from react-router-dom

function Sidebar() {
  const [isDropdownOpen, setIsDropdownOpen] = useState(false);
  const navigate = useNavigate(); // Initialize useNavigate

  const toggleDropdown = () => {
    setIsDropdownOpen(!isDropdownOpen);
  };

  const handleLogout = () => {
    const confirmLogout = window.confirm("Are you sure you want to logout?");
    if (confirmLogout) {
      navigate("/"); // Navigate to logout page if confirmed
    }
  };

  return (
    <div className="w-64 bg-gray-800 text-white flex flex-col h-screen">
      <div className="p-4 text-xl font-semibold"></div>
      <nav className="flex-1">
        <ul className="space-y-2">
          {/* Dashboard button */}
          <li>
            <button
              onClick={() => navigate("/dashboard")}
              className="w-full text-left p-4 hover:bg-gray-700"
            >
              Dashboard
            </button>
          </li>
          {/* Listings Management dropdown */}
          <li>
            <button
              onClick={toggleDropdown}
              className="w-full text-left flex items-center p-4 border border-gray-900 hover:bg-gray-700"
            >
              Listings Management
              <HiOutlineChevronDown
                className={`ml-2 ${
                  isDropdownOpen ? "transform rotate-180" : ""
                }`}
              />
            </button>
            {isDropdownOpen && (
              <ul className="space-y-2 pl-6">
                <li>
                  <button
                    onClick={() => navigate("/listings")}
                    className="w-full text-left p-4 hover:bg-gray-700"
                  >
                    Active Listings
                  </button>
                </li>
                <li>
                  <button
                    onClick={() => navigate("/addlist")}
                    className="w-full text-left p-4 hover:bg-gray-700"
                  >
                    Add New Listing
                  </button>
                </li>
              </ul>
            )}
          </li>
          {/* Additional buttons */}
          <li>
            <button
              onClick={() => navigate("/profile_update")}
              className="w-full text-left p-4 hover:bg-gray-700"
            >
              Edit Profile
            </button>
            <button
              onClick={() => navigate("/reqcat")}
              className="w-full text-left p-4 hover:bg-gray-700"
            >
              Request Category
            </button>
            <button
              onClick={() => navigate("/upload")}
              className="w-full text-left p-4 hover:bg-gray-700"
            >
              Featured Advertisement
            </button>
            <button
              onClick={() => navigate("/video")}
              className="w-full text-left p-4 hover:bg-gray-700"
            >
              Featured Video
            </button>
          </li>
          <li>
            <button
              onClick={() => navigate("/resetpwd")}
              className="w-full text-left p-4 hover:bg-gray-700"
            >
              Change Password
            </button>
          </li>
        </ul>
      </nav>
      <div className="p-4 border-t border-gray-700">
        <button
          onClick={handleLogout} // Use handleLogout function for logout
          className="w-full text-left flex items-center p-4 hover:bg-gray-700"
        >
          Logout
        </button>
      </div>
    </div>
  );
}

export default Sidebar;
